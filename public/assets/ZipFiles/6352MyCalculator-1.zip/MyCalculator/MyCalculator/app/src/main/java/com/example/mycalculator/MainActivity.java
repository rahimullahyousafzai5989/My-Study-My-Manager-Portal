package com.example.mycalculator;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HorizontalScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Calculator calculator;
    private TextView displayPrimary;
    private TextView displaySecondary;
    private HorizontalScrollView hsv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        displayPrimary = (TextView) findViewById(R.id.display_primary);
        displaySecondary = (TextView) findViewById(R.id.display_secondary);
        hsv = (HorizontalScrollView) findViewById(R.id.display_hsv);
        TextView[] digits = {
                (TextView) findViewById(R.id.button_0),
                (TextView) findViewById(R.id.button_1),
                (TextView) findViewById(R.id.button_2),
                (TextView) findViewById(R.id.button_3),
                (TextView) findViewById(R.id.button_4),
                (TextView) findViewById(R.id.button_5),
                (TextView) findViewById(R.id.button_6),
                (TextView) findViewById(R.id.button_7),
                (TextView) findViewById(R.id.button_8),
                (TextView) findViewById(R.id.button_9)
        };
        for (int i = 0; i < digits.length; i++) {
            final String id = (String) digits[i].getText();
            digits[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    calculator.digit(id.charAt(0));
                }
            });
        }
        TextView[] buttons = {
                (TextView) findViewById(R.id.button_sin),
                (TextView) findViewById(R.id.button_cos),
                (TextView) findViewById(R.id.button_tan),
                (TextView) findViewById(R.id.button_ln),
                (TextView) findViewById(R.id.button_log),
                (TextView) findViewById(R.id.button_factorial),
                (TextView) findViewById(R.id.button_pi),
                (TextView) findViewById(R.id.button_e),
                (TextView) findViewById(R.id.button_exponent),
                (TextView) findViewById(R.id.button_start_parenthesis),
                (TextView) findViewById(R.id.button_end_parenthesis),
                (TextView) findViewById(R.id.button_square_root),
                (TextView) findViewById(R.id.button_add),
                (TextView) findViewById(R.id.button_subtract),
                (TextView) findViewById(R.id.button_multiply),
                (TextView) findViewById(R.id.button_divide),
                (TextView) findViewById(R.id.button_decimal),
                (TextView) findViewById(R.id.button_equals)};
        for (int i = 0; i < buttons.length; i++) {
            final String id = (String) buttons[i].getText();
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (id.equals("sin"))
                        calculator.opNum('s');
                    if (id.equals("cos"))
                        calculator.opNum('c');
                    if (id.equals("tan"))
                        calculator.opNum('t');
                    if (id.equals("ln"))
                        calculator.opNum('n');
                    if (id.equals("log"))
                        calculator.opNum('l');
                    if (id.equals("!"))
                        calculator.numOp('!');
                    if (id.equals("π"))
                        calculator.num('π');
                    if (id.equals("e"))
                        calculator.num('e');
                    if (id.equals("^"))
                        calculator.numOpNum('^');
                    if (id.equals("("))
                        calculator.parenthesisLeft();
                    if (id.equals(")"))
                        calculator.parenthesisRight();
                    if (id.equals("√"))
                        calculator.opNum('√');
                    if (id.equals("÷"))
                        calculator.numOpNum('/');
                    if (id.equals("×"))
                        calculator.numOpNum('*');
                    if (id.equals("−"))
                        calculator.numOpNum('-');
                    if (id.equals("+"))
                        calculator.numOpNum('+');
                    if (id.equals("."))
                        calculator.decimal();
                    if (id.equals("=") && !getText().equals(""))
                        calculator.equal();
                }
            });
        }
        findViewById(R.id.button_delete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculator.delete();
            }
        });

        calculator = new Calculator(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        setText(getText());
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString("text", getText());
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        setText(savedInstanceState.getString("text"));
    }

    public String getText() {
        return calculator.getText();
    }

    public void setText(String s) {
        calculator.setText(s);
    }

    public void displayPrimaryScrollLeft(String val) {
        displayPrimary.setText(formatToDisplayMode(val));
        ViewTreeObserver vto = hsv.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                hsv.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                hsv.fullScroll(View.FOCUS_LEFT);
            }
        });
    }

    public void displayPrimaryScrollRight(String val) {
        displayPrimary.setText(formatToDisplayMode(val));
        ViewTreeObserver vto = hsv.getViewTreeObserver();
        vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                hsv.getViewTreeObserver().removeGlobalOnLayoutListener(this);
                hsv.fullScroll(View.FOCUS_RIGHT);
            }
        });
    }

    public void displaySecondary(String val) {
        displaySecondary.setText(formatToDisplayMode(val));
    }

    private String formatToDisplayMode(String s) {
        return s.replace("/", "÷").replace("*", "×").replace("-", "−")
                .replace("n ", "ln(").replace("l ", "log(").replace("√ ", "√(")
                .replace("s ", "sin(").replace("c ", "cos(").replace("t ", "tan(")
                .replace(" ", "").replace("∞", "Infinity").replace("NaN", "Undefined");
    }

}
